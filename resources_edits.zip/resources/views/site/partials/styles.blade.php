<link rel="apple-touch-icon" sizes="180x180" href="{{asset("resources/site/img/fav.png")}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{asset("resources/site/css/bootstrap.min.css")}}">
<link rel="stylesheet" type="text/css" href="{{asset("resources/site/css/slick.css")}}" />
<link rel="stylesheet" type="text/css" href="{{asset("resources/site/css/slick-theme.css")}}" />
<script src="{{asset("resources/site/scripts/swiper-bundle.min.js")}}"></script>
<link href="{{asset("resources/site/css/swiper-bundle.min.css")}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset("resources/site/css/header.css")}}">
<link rel="stylesheet" href="{{asset("resources/site/css/footer.css")}}">
<link href="{{url("resources/site/css/sweetalert/sweetalert.min.css")}}" rel="stylesheet">
<link href="https://fonts.cdnfonts.com/css/sakkal-majalla-2" rel="stylesheet">
@stack("styles")
