<link href="{{url("resources/dashboard/vendors/bootstrap/dist/css/bootstrap.min.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/vendors/font-awesome/css/font-awesome.min.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/vendors/nprogress/nprogress.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/vendors/animate.css/animate.min.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/vendors/switchery/dist/switchery.min.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/vendors/sweetalert/sweetalert.min.css")}}" rel="stylesheet">
<link href="{{url("resources/dashboard/build/css/custom.css")}}" rel="stylesheet">
<style>
    .nav-md .site_title img{
        width: 12rem;
    }
    .nav-sm .site_title img{
        width: 10rem;
    }
    .nav-sm .nav_title{
        padding-left: 0px !important;
    }
    label {
        font-weight: bold;
        color: #1e347b;
    }
</style>
@stack("styles")
