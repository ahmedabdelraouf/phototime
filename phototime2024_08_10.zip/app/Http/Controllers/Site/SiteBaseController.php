<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;

class SiteBaseController extends Controller
{

}
