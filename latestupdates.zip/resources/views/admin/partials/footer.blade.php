<footer>
    <div class="pull-left">
        <i class="fa fa-laptop"></i> Phototime
    </div>
    <div class="pull-right">
        ©{{date("Y")}} All Rights Reserved. Phototime (Photo time فوتوتايم)
    </div>
    <div class="clearfix"></div>
</footer>
