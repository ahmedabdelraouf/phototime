<script src="{{url("resources/dashboard/vendors/jquery/dist/jquery.min.js")}}"></script>
<script src="{{url("resources/dashboard/vendors/bootstrap/dist/js/bootstrap.bundle.min.js")}}"></script>
<script src="{{url("resources/dashboard/vendors/switchery/dist/switchery.min.js")}}"></script>
<script src="{{url("resources/dashboard/vendors/sweetalert/sweetalert.min.js")}}"></script>
@stack("scripts")
<script src="{{url("resources/dashboard/build/js/custom.js")}}"></script>
@include("admin.partials.sweat_alert")
